Put the image files from the other zip file in here. We have separated thme to make the application files smaller to download. 
